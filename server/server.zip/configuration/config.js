const nodemailer = require('nodemailer');

const alamatServer = `http://localhost:5014/`
// const alamatServer = `http://report.pmb.univ-mw.com/`
const alamatClient = `https://pmb.univ-mw.com/`



module.exports = {
    alamatServer : alamatServer,
    alamatClient : alamatClient,
}


